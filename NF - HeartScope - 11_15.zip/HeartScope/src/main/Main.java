package main;

import java.util.ArrayList;





public class Main {
	

	
    public static void main(String[] args){
    	
    	
    	
        // Import the dataset
        String originalDataFilePath = "src/data/HeartScope_Dataset.csv";
    	Dataset dataset = new Dataset(originalDataFilePath, true);
    	SOP("Dataset Created");
    	//SOP(dataset);
    	//SOP(dataset.getShape());

    	
    	/*
    	// Make a copy of the dataset and normalize the copy, preserving the original dataset
    	//Dataset normalizedDataset = dataset.newCopy();
    	//normalizedDataset.normalizeDataset();
    	//SOP("Dataset Normalized");
    	//SOP(normalizedDataset);
    	//SOP(normalizedDataset.getShape());
    	*/
		
    	// Split the Dataset into a ValidationData object, which stores 10 folds of training and testing data
    	ValidationData validation = new ValidationData(dataset);
    	ArrayList<Dataset> trainingFolds = validation.trainingDataFolds;
    	ArrayList<Dataset> testingFolds = validation.testingDataFolds;

    	
    	// TODO Create and Train Random Forest
    	
    	
    	
    	
    	
    	
    	// Make a prediction
    	
    	
    	// Get UserInput
    	SOP("Getting UserInput...");
    	String userInput = "55,F,ATA, 130, 215, 0, LVH, 132, Y, 0, Up, 0";
    	SOP("UserInput:\t " + userInput);

    	SOP("Converting UserInput to UserData...");
        UserData fakeUser = new UserData(userInput);
    	SOP("UserData:\t " + fakeUser);

    	/*
    	//SOP("Normalizing User into the Normalized Dataset...");
        //fakeUser.normalize(normalizedDataset);
    	//SOP("Normalized UserInput:\t " + fakeUser);
    	 */

    	
        
        // TODO Predict
        

    	
    	
    	// Get the additional information for that user
    	SOP("Calculating Average Values within the user's range...");
    	UserData averageValues = fakeUser.getAdditionalInformation(dataset);
    	SOP("Normalized Avg Values:\t " + averageValues);   	
    	
    	/*
    	//SOP("Denormalizing the values...");
    	//UserData avgValues = normalizedAverageValues.denormalize(normalizedDataset);
    	//SOP("Avg Values:\t " + avgValues);
		*/
    	
    	
    	// TODO Display the results to the user
    	SOP("Finished");
    	System.exit(0);
    }
    
    
    
    private static void SOP(Object o) {
    	System.out.println(o + "\n");
    }
    
}

