package main;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Arrays;

import org.junit.jupiter.api.Test;

class DatasetTest {
	
	@Test
	void FilterDatasetTestNormal() {
		Dataset originalDataset = new Dataset();

		String[] originalTestEntries = new String[]{
				"44,M,ATA,140,289,0,Normal,172,N,0,Up,0",
				"45,M,NAP,160,180,0,Normal,156,N,1,Flat,1",
				"46,M,ATA,130,283,0,ST,98,N,0,Up,0",
				"47,M,ASY,138,214,0,Normal,108,Y,1.5,Flat,1",
				"48,M,NAP,150,195,0,Normal,122,N,0,Up,0",
				"49,M,NAP,120,339,0,Normal,170,N,0,Up,0",
				"50,M,ASY,140,207,0,Normal,130,Y,1.5,Flat,1",
				"44,F,ATA,140,289,0,Normal,172,N,0,Up,0",
				"45,F,NAP,160,180,0,Normal,156,N,1,Flat,1",
				"46,F,ATA,130,283,0,ST,98,N,0,Up,0",
				"47,F,ASY,138,214,0,Normal,108,Y,1.5,Flat,1",
				"48,F,NAP,150,195,0,Normal,122,N,0,Up,0",
				"49,F,NAP,120,339,0,Normal,170,N,0,Up,0",
				"50,F,ASY,140,207,0,Normal,130,Y,1.5,Flat,1",
		};
		 
		for(String e : originalTestEntries) {
			originalDataset.add(new UserData(e));
		}
		 
		// Create the expectation
		UserData testUser = new UserData("47,M,ASY,138,214,0,Normal,108,Y,1.5,Flat,1");
		Dataset expectedDataset = new Dataset();
		 
		String[] expectedTestEntries = new String[]{
				"45,M,NAP,160,180,0,Normal,156,N,1,Flat,1",
				"46,M,ATA,130,283,0,ST,98,N,0,Up,0",
				"47,M,ASY,138,214,0,Normal,108,Y,1.5,Flat,1",
				"48,M,NAP,150,195,0,Normal,122,N,0,Up,0",
				"49,M,NAP,120,339,0,Normal,170,N,0,Up,0",
		};
		 
		for(String e : expectedTestEntries) {
			expectedDataset.add(new UserData(e));
		}
		 
		// Create the actual
		originalDataset.filterAgeAndSex(testUser);
		Dataset actualDataset = originalDataset.newCopy();
		 
	   	// Assert that expected equals actual 	
		assertEquals(expectedDataset, actualDataset);
		
	}
	
	
	@Test
	void FilterDatasetTestNoMatches() {
		Dataset originalDataset = new Dataset();

		String[] originalTestEntries = new String[]{
				"44,M,ATA,140,289,0,Normal,172,N,0,Up,0",
				"45,M,NAP,160,180,0,Normal,156,N,1,Flat,1",
				"46,M,ATA,130,283,0,ST,98,N,0,Up,0",
				"47,M,ASY,138,214,0,Normal,108,Y,1.5,Flat,1",
				"48,M,NAP,150,195,0,Normal,122,N,0,Up,0",
				"49,M,NAP,120,339,0,Normal,170,N,0,Up,0",
				"50,M,ASY,140,207,0,Normal,130,Y,1.5,Flat,1",
				"44,F,ATA,140,289,0,Normal,172,N,0,Up,0",
				"45,F,NAP,160,180,0,Normal,156,N,1,Flat,1",
				"46,F,ATA,130,283,0,ST,98,N,0,Up,0",
				"47,F,ASY,138,214,0,Normal,108,Y,1.5,Flat,1",
				"48,F,NAP,150,195,0,Normal,122,N,0,Up,0",
				"49,F,NAP,120,339,0,Normal,170,N,0,Up,0",
			 	"50,F,ASY,140,207,0,Normal,130,Y,1.5,Flat,1",
		};
		 
		for(String e : originalTestEntries) {
			 originalDataset.add(new UserData(e));
		}
		 
		// Create the expectation
		UserData testUser = new UserData("80,M,ASY,138,214,0,Normal,108,Y,1.5,Flat,1");
		Dataset expectedDataset = new Dataset();
		
		String[] expectedTestEntries = new String[]{
				"44,M,ATA,140,289,0,Normal,172,N,0,Up,0",
				"45,M,NAP,160,180,0,Normal,156,N,1,Flat,1",
				"46,M,ATA,130,283,0,ST,98,N,0,Up,0",
				"47,M,ASY,138,214,0,Normal,108,Y,1.5,Flat,1",
				"48,M,NAP,150,195,0,Normal,122,N,0,Up,0",
				"49,M,NAP,120,339,0,Normal,170,N,0,Up,0",
				"50,M,ASY,140,207,0,Normal,130,Y,1.5,Flat,1"
		};
		 
		for(String e : expectedTestEntries) {
			expectedDataset.add(new UserData(e));
		}
		 
		// Create the actual
		originalDataset.filterAgeAndSex(testUser);
		Dataset actualDataset = originalDataset.newCopy();
		 
   		// Assert that expected equals actual 	
		assertEquals(expectedDataset, actualDataset);
	}
	
	
	@Test
	void getAverageValuesTestNormal() {
		Dataset originalDataset = new Dataset();

		String[] originalTestEntries = new String[]{
				 "40, M, ATA, 140, 289,	0, Normal, 172, N, 0, Up, 0",
				 "49, M, NAP, 160, 180,	0, Normal, 156,	N, 1, Flat,	1",
				 "37, M, ATA, 130, 283,	0, ST, 98, N, 0, Up, 0",
				 "48, M, ASY, 138, 214,	0, Normal, 108,	Y, 1.5,	Flat, 1",
				 "54, M, NAP, 150, 195,	0, Normal, 122,	N, 0, Up, 0",
				 "39, M, NAP, 120, 339,	0, Normal, 170,	N, 0, Up, 0",
				 "45, M, ATA, 130, 237,	0, Normal, 170,	N, 0, Up, 0",
				 "54, M, ATA, 110, 208,	0, Normal, 142,	N, 0, Up, 0",
				 "37, M, ASY, 140, 207,	0, Normal, 130,	Y, 1.5,	Flat, 1",
				 "48, M, ATA, 120, 284,	0, Normal, 120,	N, 0, Up, 0",
		 };
		 
		for(String e : originalTestEntries) {
			originalDataset.add(new UserData(e));
		}
		 		 
		// Create the expectation	 
		ArrayList<Number> expected = new ArrayList<Number>() {{
			add(45);
			add(0);
			add(1);
			add(0);
			add(0);
			add(0);
			add(133);
			add(243);
			add(0);
			add(1);
			add(0);
			add(0);
			add(138);
			add(0);
			add(0.4f);
			add(0);
			add(0);
			add(1);
			add(0);
		}};
		
		
		// Create the actual
		UserData actual = originalDataset.getAvgValues();
		 
	   	// Assert that expected equals actual 	
		assertEquals(expected, actual);
	}
	
	
	
	@Test
	void getAverageValuesTestEmptyDatabase() {
		Dataset originalDataset = new Dataset();

		// Create the expectation	 
		ArrayList<Number> expected = new ArrayList<Number>() {{
			add(-1);
			add(-1);
			add(-1);
			add(-1);
			add(-1);
			add(-1);
			add(-1);
			add(-1);
			add(-1);
			add(-1);
			add(-1);
			add(-1);
			add(-1);
			add(-1);
			add(-1);
			add(-1);
			add(-1);
			add(-1);
			add(-1);
		}};
				
		// Create the actual
		UserData actual = originalDataset.getAvgValues();

		// Assert that expected equals actual 	
		assertEquals(expected, actual);
	}
	
	
	
	/*
	void getNormalizedDataZeroEntriesTest() {
		Dataset originalDataset = new Dataset();

		String[] originalTestEntries = new String[]{
		};
		 
		for(String e : originalTestEntries) {
			originalDataset.add(new UserData(e));
		}
		 
		// Create the expectation
		Dataset expectedDataset = new Dataset();

		// Create the actual
		originalDataset.normalizeDataset();
		Dataset actualDataset = originalDataset.newCopy();
		
		// Assert that expected equals actual 	
		assertEquals(expectedDataset, actualDataset);
	}
	
	
	
	
	void getNormalizedDataOneEntryTest() {
		Dataset originalDataset = new Dataset();

		String[] originalTestEntries = new String[]{
				"44,M,ATA,140,289,0,Normal,172,N,0,Up,0"
		};
		 
		for(String e : originalTestEntries) {
			originalDataset.add(new UserData(e));
		}
		 
		// Create the expectation
		Dataset expectedDataset = new Dataset();
		expectedDataset.add(new UserData("44,M,ATA,140,289,0,Normal,172,N,0,Up,0"));

		// Create the actual
		originalDataset.normalizeDataset();
		Dataset actualDataset = originalDataset.newCopy();
		
		// Assert that expected equals actual 	
		assertEquals(expectedDataset, actualDataset);
	}
	
	
	void getNormalizedDataMultipleEntriesTest() {
		Dataset originalDataset = new Dataset();

		String[] originalTestEntries = new String[]{
				"40,M,ATA,140,289,0,Normal,172,N,0,Up,0",
				"49,F,NAP,160,180,0,Normal,156,N,1,Flat,1",
				"37,M,ATA,130,283,0,ST,98,N,0,Up,0",
		};
		 
		for(String e : originalTestEntries) {
			originalDataset.add(new UserData(e));
		}
		 
		// Create the expectation
		Dataset expectedDataset = new Dataset();
		
		Float[] u1Normalized = {40f, 0f, 0f, 0.3333333333f, 1f, 0f, 0f, 1f, 0f, 0f, 2f, 0f};
		Float[] u2Normalized = {49f, 1f, 1f, 1f, 0f, 0f, 0f, 0.7837837838f, 0f, 1f, 1f, 1f};
		Float[] u3Normalized = {37f, 0f, 0f, 0f, .9449541284f, 0f, 1f, 0f, 0f, 0f, 2f, 0f};
		
		UserData u1 = new UserData() {{
			for(int i=0; i<this.getDESIRED_NUM_OUTPUT_INDICES(); i++) {
				this.set(i, u1Normalized[i]);
			}
		}};
		
		UserData u2 = new UserData() {{
			for(int i=0; i<this.getDESIRED_NUM_OUTPUT_INDICES(); i++) {
				this.set(i, u2Normalized[i]);
			}
		}};
		
		UserData u3 = new UserData() {{
			for(int i=0; i<this.getDESIRED_NUM_OUTPUT_INDICES(); i++) {
				this.set(i, u3Normalized[i]);
			}
		}};
		
		expectedDataset.add((UserData) u1);
		expectedDataset.add((UserData) u2);
		expectedDataset.add((UserData) u3);

		// Create the actual
		originalDataset.normalizeDataset();
		Dataset actualDataset = originalDataset.newCopy();
		
		// Assert that expected equals actual 	
		assertEquals(expectedDataset, actualDataset);
	}
	*/
	
	
	

}
