package main;

import static org.junit.jupiter.api.Assertions.*;
import java.util.ArrayList;
import org.junit.jupiter.api.Test;

class UserDataTest {

	
	Dataset d;
	
	@Test
	void fullUserData() {
    	
		// Create the expectation
		ArrayList<Number> expected = new ArrayList<Number>() {{
			add(40);
			add(0);
			add(1);
			add(0);
			add(0);
			add(0);
			add(140);
			add(289);
			add(0);
			add(1);
			add(0);
			add(0);
			add(172);
			add(0);
			add(0.0f);
			add(0);
			add(0);
			add(1);
			add(0);
		}};
		
		// Create the actual
		String[] test = {"40", "M", "ATA", "140", "289", "0", "Normal", "172", "N", "0", "Up", "0"};
    	UserData actual = new UserData(test);

    	// Assert that expected equals actual
    	assertEquals(expected, actual);
	}
	
	@Test
	void partialUserData() {
    	
		// Create the expectation
		ArrayList<Number> expected = new ArrayList<Number>() {{
			add(40);
			add(0);
			add(1);
			add(0);
			add(0);
			add(0);
			add(140);
			add(289);
			add(0);
			add(1);
			add(0);
			add(0);
			add(172);
			add(0);
			add(0.0f);
			add(0);
			add(1);
			add(0);
			add(0);
		}};
		
		// Create the actual
		String[] test = {"40", "M", "", "140", "289", "", "", "172", "N", "", "", "0"};
    	UserData actual = new UserData(test);

    	// Assert that expected equals actual
    	assertEquals(expected, actual);
	}
	
	@Test
	void emptyUserData() {
    	
		// Create the expectation
		ArrayList<Number> expected = new ArrayList<Number>() {{
			add(0);
			add(0);
			add(1);
			add(0);
			add(0);
			add(0);
			add(133);
			add(245);
			add(0);
			add(1);
			add(0);
			add(0);
			add(137);
			add(0);
			add(0.0f);
			add(0);
			add(1);
			add(0);
			add(0);
		}};
		
		// Create the actual
		String[] test = {"", "", "", "", "", "", "", "", "", "", "", ""};
    	UserData actual = new UserData(test);

    	// Assert that expected equals actual
    	assertEquals(expected, actual);
	}

	
	/*
	void normalizeUserDataOutsideZeroOneInterval() {
		
		Dataset d = new Dataset();
		
		d.add(new UserData(new String[]{"40", "M", "ASY", "220", "290", "1", "ST", "150", "Y", "0", "Up", "0"}));
		d.add(new UserData(new String[]{"20", "F", "TA", "120", "280", "0", "Normal", "120", "N", "1", "Down", "1"}));
		d.normalizeDataset();

		// Create the expectation
		ArrayList<Number> expected = new ArrayList<Number>() {{
			add(40f);
			add(0f);
			add(0f);
			add(0.2f);
			add(0.9f);
			add(0f);
			add(0f);
			add(1.7333333f);
			add(0f);
			add(0f);
			add(2f);
			add(0f);
		}};
		
		// Create the actual
		String[] test = {"40", "M", "ATA", "140", "289", "0", "Normal", "172", "N", "0", "Up", "0"};
    	UserData actual = new UserData(test);
    	actual.normalize(d);

    	// Assert that expected equals actual
    	assertEquals(expected, actual);
	}
	
	
	void normalizeUserDataTest() {
		
		Dataset d = new Dataset();
		
		d.add(new UserData(new String[]{"40", "F", "ASY", "220", "290", "1", "ST", "150", "Y", "1", "Up", "1"}));
		d.add(new UserData(new String[]{"36", "M", "NAP", "212", "215", "0", "Normal", "136", "N", "0", "Down", "0"}));
		d.normalizeDataset();

		// Create the expectation
		ArrayList<Number> expected = new ArrayList<Number>() {{
			add(37f);
			add(0f);
			add(0f);
			add(0.75f);
			add(-0.21333334f);
			add(0f);
			add(2f);
			add(-0.42857143f);
			add(1f);
			add(1f);
			add(0f);
			add(1f);
		}};

		// Create the actual
		String[] test = {"37", "M", "ATA", "218", "199", "0", "LVH", "130", "Y", "1", "Down", "1"};
    	UserData actual = new UserData(test);
    	actual.normalize(d);

    	// Assert that expected equals actual
    	assertEquals(expected, actual);
	}
	
	
	
	
	void normalizeUserDataAllZero() {
		
		Dataset d = new Dataset();
		
		d.add(new UserData(new String[]{"40", "F", "ASY", "220", "290", "1", "ST", "150", "Y", "1", "Up", "1"}));
		d.add(new UserData(new String[]{"0", "M", "ATA", "0", "0", "0", "Normal", "0", "N", "0", "Flat", "0"}));
		d.normalizeDataset();

		// Create the expectation
		ArrayList<Number> expected = new ArrayList<Number>() {{
			add(0f);
			add(0f);
			add(0f);
			add(0f);
			add(0f);
			add(0f);
			add(0f);
			add(0f);
			add(0f);
			add(0f);
			add(1f);
			add(0f);
		}};
		
		// Create the actual
		String[] test = {"0", "M", "ATA", "0", "0", "0", "Normal", "0", "N", "0", "Flat", "0"};
    	UserData actual = new UserData(test);
    	actual.normalize(d);

    	// Assert that expected equals actual
    	assertEquals(expected, actual);
	}
	
	
	void returnUserDataNormalized() {

		Dataset d = new Dataset();
		
		d.add(new UserData(new String[]{"40", "M", "ASY", "220", "290", "1", "ST", "150", "Y", "0", "Up", "0"}));
		d.add(new UserData(new String[]{"20", "F", "TA", "120", "280", "0", "Normal", "120", "N", "1", "Down", "1"}));
		d.normalizeDataset();

		// Create the expectation
		String[] expected = {"40.0", "0.0", "0.0" ,"0.2", "0.9", "0.0", "2.0", "1.7333333", "0.0", "0.0", "2.0", "0.0"};

		
		// Create the actual
		String[] test = {"40", "M", "ATA", "140", "289", "0", "LVH", "172", "N", "0", "Up", "0"};
    	UserData testUser = new UserData(test);
    	testUser.normalize(d);
    	String[] actual = testUser.returnUserData();

    	// Assert that expected equals actual
    	assertArrayEquals(expected, actual);

	}
	
	*/
	
	
	@Test
	void returnUserDataEmptyValues() {
		
		// Create the expectation
		String[] expected = {"0", "0", "1", "0", "0", "0", "133", "245", "0", "1", "0", "0", "137", "0", "0.0", "0", "1", "0", "0"};

		
		// Create the actual
		String[] test = {"", "", "", "", "", "", "", "", "", "", "", ""};
    	UserData testUser = new UserData(test);
    	String[] actual = testUser.returnUserData();
    
    	// Assert that expected equals actual
    	assertArrayEquals(expected, actual);
	}
	
	
	@Test
	void returnUserDataNormal() {
		
		// Create the expectation
		String[] expected = {"40", "0", "1", "0", "0", "0", "140", "289", "0", "1", "0", "0", "172", "0", "0.0", "0", "0", "1", "0"};

		
		// Create the actual
		String[] test = {"40", "M", "ATA", "140", "289", "0", "Normal", "172", "N", "0", "Up", "0"};
    	UserData testUser = new UserData(test);
    	String[] actual = testUser.returnUserData();
    	
    	// Assert that expected equals actual
    	assertArrayEquals(expected, actual);
	}
	
    	

}
