/**
 * 
 */
/**
 * 
 */
module HeartScope {
	requires org.junit.jupiter.api;
}