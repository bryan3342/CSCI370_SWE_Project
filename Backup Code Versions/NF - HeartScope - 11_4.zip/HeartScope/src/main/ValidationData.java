package main;

import java.util.ArrayList;

public class ValidationData extends ArrayList<Dataset>{

	protected ArrayList<Dataset> trainingDataFolds;	// ArrayList storing each training dataset fold
	protected ArrayList<Dataset> testingDataFolds;	// ArrayList storing each testing dataset fold
	protected ArrayList<Float> inSampleErrors;		// Arraylist storing the in-sample error produced when creating the tree
	private static int num_entries_per_testing_fold;	// The size of each testing fold, size_of_dataset / k for k-fold cross validation
	private final static int NUM_FOLDS = 10;			// The number of folds for cross validation
	

	
	public ValidationData(Dataset motherDataset) {
		/**
		 * Constructor for ValidationData
		 * 
		 * @param motherDataset The dataset this was created from
		 */
		
		// Initialize instance variables
		trainingDataFolds = new ArrayList<Dataset>();
		testingDataFolds = new ArrayList<Dataset>();
		inSampleErrors = new ArrayList<Float>();	
		num_entries_per_testing_fold = (int) Math.round((float) motherDataset.size() / NUM_FOLDS);
		
		for(int i=0; i<NUM_FOLDS; i++) {
			trainingDataFolds.add(new Dataset());
			testingDataFolds.add(new Dataset());			
			inSampleErrors.add(0f);
		}
		
		// Split the data into NUM_FOLDS partitions
		splitData(motherDataset);
	}
	
	
	private void splitData(Dataset motherDataset) {
		/**
		 * Method to split the dataset into 10 folds for training and testing.
		 */
		
		// Take the Dataset d and partition it into 10 folds
		for(int foldIndex=0; foldIndex < 10; foldIndex++) {
			
			// Set the index bounds for what should be marked as training
			int firstTestingIndex = foldIndex * num_entries_per_testing_fold;
			int lastTestingIndex = (foldIndex+1) * num_entries_per_testing_fold - 1;
			
			// Loop through the Dataset d and add entries to their proper folds
			for(int entryIndex = 0; entryIndex<motherDataset.size(); entryIndex++) {
				
				// Get the entry at that index of the motherDataset
				UserData entryToAdd = motherDataset.get(entryIndex);
				
				// If the entryIndex is between the first and last training index markers, add it to the testing fold
				if((entryIndex >= firstTestingIndex) && (entryIndex <= lastTestingIndex)) {
					testingDataFolds.get(foldIndex).add(entryToAdd);
				}
				
				// Otherwise, add it to the training fold
				else{
					trainingDataFolds.get(foldIndex).add(entryToAdd);
				}
				
			}	// end of looping through Dataset d
			
		}	// 10 folds have been created
		
	}	// splitData()
	
	
	// TODO: Implement createRandomForest
	public void createRandomForest() {}	
	
	// TODO: Implement validateRandomForest
	public void validateRandomForest() {}
		
	
	
	private static void SOP(Object o) {
    	System.out.println(o + "\n");
    }
	
	private static void SOP(ArrayList<Dataset> o) {		
		for(Dataset d : o) {
			SOP(d);
		}
    }
	
	public int get_num_entries_per_testing_fold() {
		return num_entries_per_testing_fold;
	}

}
