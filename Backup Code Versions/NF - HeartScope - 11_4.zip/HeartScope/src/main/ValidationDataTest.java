package main;

import static org.junit.jupiter.api.Assertions.*;

import java.util.HashSet;

import org.junit.jupiter.api.Test;

class ValidationDataTest {
	
	@Test
	void constructorSetsNumTestEntriesCorrectlyEvenDivision() {
		Dataset mother = new Dataset();

		String[] originalTestEntries = new String[]{
				"40,M,ATA,140,289,0,Normal,172,N,0,Up,0",
				"50,F,NAP,160,180,0,Normal,156,N,1,Flat,1",
				"38,M,NAP,130,211,0,Normal,142,N,0,Up,0",
				"63,F,ATA,120,204,0,Normal,145,N,0,Up,0",
				"41,M,ATA,130,283,0,ST,98,N,0,Up,0",
				"44,F,ASY,138,214,0,Normal,108,Y,1.5,Flat,1",
				"41,M,ATA,136,164,0,ST,99,Y,2,Flat,1",
				"51,F,ASY,140,234,0,Normal,140,Y,1,Flat,1",
				"56,M,NAP,150,195,0,Normal,122,N,0,Up,0",
				"52,F,NAP,120,339,0,Normal,170,N,0,Up,0",
				"65,M,NAP,115,211,0,ST,137,N,0,Up,0",
				"63,F,ATA,130,237,0,Normal,170,N,0,Up,0",
				"49,M,ATA,110,208,0,Normal,142,N,0,Up,0",
				"73,F,ATA,120,273,0,Normal,150,N,1.5,Flat,0",
				"51,M,ASY,140,207,0,Normal,130,Y,1.5,Flat,1",
				"54,F,ATA,120,284,0,Normal,120,N,0,Up,0",
				"34,M,ASY,110,196,0,Normal,166,N,0,Flat,1",
				"44,F,ATA,120,201,0,Normal,165,N,0,Up,0",
				"64,M,ATA,120,201,0,Normal,165,N,0,Up,0",
				"74,F,ATA,120,201,0,Normal,165,N,0,Up,0",
		};
		 
		for(String e : originalTestEntries) {
			mother.add(new UserData(e));
		}
		
		// Create the expectation
		int expected = 2;
		
		// Create the actual
		ValidationData a = new ValidationData(mother);
		int actual = a.get_num_entries_per_testing_fold();
		
	   	// Assert that expected equals actual 	
		assertEquals(expected, actual);		
	}
	
	
	
	@Test
	void constructorSetsNumTestEntriesCorrectlyOddDivision() {
		Dataset mother = new Dataset();

		String[] originalTestEntries = new String[]{
				"40,M,ATA,140,289,0,Normal,172,N,0,Up,0",
				"50,F,NAP,160,180,0,Normal,156,N,1,Flat,1",
				"38,M,NAP,130,211,0,Normal,142,N,0,Up,0",
				"63,F,ATA,120,204,0,Normal,145,N,0,Up,0",
				"41,M,ATA,130,283,0,ST,98,N,0,Up,0",
				"44,F,ASY,138,214,0,Normal,108,Y,1.5,Flat,1",
				"41,M,ATA,136,164,0,ST,99,Y,2,Flat,1",
				"51,F,ASY,140,234,0,Normal,140,Y,1,Flat,1",
				"56,M,NAP,150,195,0,Normal,122,N,0,Up,0",
				"52,F,NAP,120,339,0,Normal,170,N,0,Up,0",
				"65,M,NAP,115,211,0,ST,137,N,0,Up,0",
				"63,F,ATA,130,237,0,Normal,170,N,0,Up,0",
				"49,M,ATA,110,208,0,Normal,142,N,0,Up,0",
				"73,F,ATA,120,273,0,Normal,150,N,1.5,Flat,0",
				"51,M,ASY,140,207,0,Normal,130,Y,1.5,Flat,1",
		};
		 
		for(String e : originalTestEntries) {
			for(int i=0; i<15; i++) {
				mother.add(new UserData(e));
			}
		}
		
		// Create the expectation
		int expected = 23;
		
		// Create the actual
		ValidationData a = new ValidationData(mother);
		int actual = a.get_num_entries_per_testing_fold();
		
	   	// Assert that expected equals actual 	
		assertEquals(expected, actual);		
	}
	
	
	
	@Test
	void splitDataTestingPlusTrainingEqualsMother() {
		
		Dataset mother = new Dataset();

		String[] originalTestEntries = new String[]{
				"40,M,ATA,140,289,0,Normal,172,N,0,Up,0",
				"50,F,NAP,160,180,0,Normal,156,N,1,Flat,1",
				"38,M,NAP,130,211,0,Normal,142,N,0,Up,0",
				"63,F,ATA,120,204,0,Normal,145,N,0,Up,0",
				"41,M,ATA,130,283,0,ST,98,N,0,Up,0",
				"44,F,ASY,138,214,0,Normal,108,Y,1.5,Flat,1",
				"41,M,ATA,136,164,0,ST,99,Y,2,Flat,1",
				"51,F,ASY,140,234,0,Normal,140,Y,1,Flat,1",
				"56,M,NAP,150,195,0,Normal,122,N,0,Up,0",
				"52,F,NAP,120,339,0,Normal,170,N,0,Up,0",
				"65,M,NAP,115,211,0,ST,137,N,0,Up,0",
				"63,F,ATA,130,237,0,Normal,170,N,0,Up,0",
				"49,M,ATA,110,208,0,Normal,142,N,0,Up,0",
				"73,F,ATA,120,273,0,Normal,150,N,1.5,Flat,0",
				"51,M,ASY,140,207,0,Normal,130,Y,1.5,Flat,1",
				"54,F,ATA,120,284,0,Normal,120,N,0,Up,0",
				"34,M,ASY,110,196,0,Normal,166,N,0,Flat,1",
				"44,F,ATA,120,201,0,Normal,165,N,0,Up,0",
		};
		 
		for(String e : originalTestEntries) {
			mother.add(new UserData(e));
		}
		
		// Create the expectation
		Dataset expected = mother;
		
		// Create the actual
		ValidationData a = new ValidationData(mother);		

		Dataset actual = a.trainingDataFolds.get(0);
		Dataset test = a.testingDataFolds.get(0);
			
		for(UserData entry : test) {
			actual.add(entry);
		}
			
		// Assert that expected equals actual 	
		assertEquals(new HashSet<>(expected), new HashSet<>(actual));	
	}
	
	
	
	@Test
	void splitDataAggregateAllTrainingEqualsNineMothers() {
		Dataset mother = new Dataset();

		String[] originalTestEntries = new String[]{
				"40,M,ATA,140,289,0,Normal,172,N,0,Up,0",
				"50,F,NAP,160,180,0,Normal,156,N,1,Flat,1",
				"38,M,NAP,130,211,0,Normal,142,N,0,Up,0",
				"63,F,ATA,120,204,0,Normal,145,N,0,Up,0",
				"41,M,ATA,130,283,0,ST,98,N,0,Up,0",
				"44,F,ASY,138,214,0,Normal,108,Y,1.5,Flat,1",
				"41,M,ATA,136,164,0,ST,99,Y,2,Flat,1",
				"51,F,ASY,140,234,0,Normal,140,Y,1,Flat,1",
				"56,M,NAP,150,195,0,Normal,122,N,0,Up,0",
				"52,F,NAP,120,339,0,Normal,170,N,0,Up,0",
				"65,M,NAP,115,211,0,ST,137,N,0,Up,0",
				"63,F,ATA,130,237,0,Normal,170,N,0,Up,0",
				"49,M,ATA,110,208,0,Normal,142,N,0,Up,0",
				"73,F,ATA,120,273,0,Normal,150,N,1.5,Flat,0",
				"51,M,ASY,140,207,0,Normal,130,Y,1.5,Flat,1",
				"54,F,ATA,120,284,0,Normal,120,N,0,Up,0",
				"34,M,ASY,110,196,0,Normal,166,N,0,Flat,1",
				"44,F,ATA,120,201,0,Normal,165,N,0,Up,0",
		};
		
		for(String e : originalTestEntries) {
			mother.add(new UserData(e));
		}
		
		// Create the expectation
		Dataset expected = new Dataset();
		for(int i=0; i<9; i++) {	// 9 mothers
			for(UserData entry : mother) {
				expected.add(entry);
			}
		}
		
		// Create the actual
		Dataset actual = new Dataset();

		ValidationData a = new ValidationData(mother);
		
		for(Dataset trainFold : a.trainingDataFolds) {
			for(UserData entry : trainFold) {
				actual.add(entry);
			}
		}
			
		// Assert that expected equals actual 	
		assertEquals(new HashSet<>(expected), new HashSet<>(actual));		
	}
	
	
	
	@Test
	void splitDataAggregateAllTestingEqualsMother() {
		Dataset mother = new Dataset();

		String[] originalTestEntries = new String[]{
				"40,M,ATA,140,289,0,Normal,172,N,0,Up,0",
				"50,F,NAP,160,180,0,Normal,156,N,1,Flat,1",
				"38,M,NAP,130,211,0,Normal,142,N,0,Up,0",
				"63,F,ATA,120,204,0,Normal,145,N,0,Up,0",
				"41,M,ATA,130,283,0,ST,98,N,0,Up,0",
				"44,F,ASY,138,214,0,Normal,108,Y,1.5,Flat,1",
				"41,M,ATA,136,164,0,ST,99,Y,2,Flat,1",
				"51,F,ASY,140,234,0,Normal,140,Y,1,Flat,1",
				"56,M,NAP,150,195,0,Normal,122,N,0,Up,0",
				"52,F,NAP,120,339,0,Normal,170,N,0,Up,0",
				"65,M,NAP,115,211,0,ST,137,N,0,Up,0",
				"63,F,ATA,130,237,0,Normal,170,N,0,Up,0",
				"49,M,ATA,110,208,0,Normal,142,N,0,Up,0",
				"73,F,ATA,120,273,0,Normal,150,N,1.5,Flat,0",
				"51,M,ASY,140,207,0,Normal,130,Y,1.5,Flat,1",
				"54,F,ATA,120,284,0,Normal,120,N,0,Up,0",
				"34,M,ASY,110,196,0,Normal,166,N,0,Flat,1",
				"44,F,ATA,120,201,0,Normal,165,N,0,Up,0",
		};
		
		for(String e : originalTestEntries) {
			mother.add(new UserData(e));
		}
		
		// Create the expectation
		Dataset expected = new Dataset();
		for(UserData entry : mother) {
			expected.add(entry);
		}
		
		// Create the actual
		Dataset actual = new Dataset();

		ValidationData a = new ValidationData(mother);
		
		for(Dataset testFold : a.testingDataFolds) {
			for(UserData entry : testFold) {
				actual.add(entry);
			}
		}
			
		// Assert that expected equals actual 	
		assertEquals(new HashSet<>(expected), new HashSet<>(actual));			
	}
	
	
	
}
