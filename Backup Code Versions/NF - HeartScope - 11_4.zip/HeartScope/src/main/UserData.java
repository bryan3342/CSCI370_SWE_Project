package main;

import java.util.ArrayList;

public class UserData extends ArrayList<Float> {
	
	/**
	 * -----------------------------------------------------------------------------------------------------------------------------------------------------------
	 * |  Attribute | Age | Sex | ChestPainType | RestingBP | Cholesterol | FastingBS | RestingECG | MaxHR | ExerciseAngina | Oldpeak | ST_Slope | HeartDisease |	
	 * -----------------------------------------------------------------------------------------------------------------------------------------------------------
	 * |     Index  |  0  |  1  |       2       |     3     |       4     |     5     |     6      |   7   |        8       |    9    |    10    |      11      |
	 * -----------------------------------------------------------------------------------------------------------------------------------------------------------
	 *
	 * 1) Sex: 0 - M, 1 - F
	 * 2) ChestPainType: 0 - ATA, 1 - NAP, 2 - ASY, 3 - TA
	 * 6) RestingECG: 0 - Normal, 1 - ST, 2 - LVH
	 * 8) ExerciseAngina: 0 - N, 1 - Y
	 * 10) ST_Slope: 0 - Down, 1 - Flat, 2 - Up
	 */
	
	
	
	// Instance variables
	protected int numIndices;	// Number of indices in an instance of UserData (length of this)
	private static int DESIRED_NUM_INDICES = 12;	// Number of features in the dataset
	
	public UserData() {
		// Initialize the UserData with all -1 sentinel and return
		for(int index=0; index<DESIRED_NUM_INDICES; index++) {
			this.add(0f);
		}
		this.numIndices = DESIRED_NUM_INDICES;
	}
	
	public UserData(String userInput) {
		/**
		 * Constructor of UserData
		 * 
		 * @param userInput A String containing the necessary information to create an entry in the dataset (an instance of UserData)
		 */

		// Split the String into a String[] and call the other constructor
		this(userInput.split(","));
	}
	
	
	
	public UserData(String[] userInput) {
		/**
		 * Constructor of UserData
		 * 
		 * @param userInput A String array containing the necessary information to create an entry in the dataset (an instance of UserData)
		 */
		
		// Set the number of indices to be this.DESIRED_NUM_INDICES
		this.numIndices = DESIRED_NUM_INDICES;
		
		// If the userInput String[] is null or does not have enough entries...
		if(userInput == null || userInput.length != this.numIndices) {
			
			// Initialize the UserData with all -1 sentinel and return
			for(int index=0; index<this.numIndices; index++) {
				this.add(null);
			}
			
			return;
		}
		
		// Otherwise, if the String[] is the correct length...
		else {

			// Initialize to be an ArrayList of all 0.0
			for(int index=0; index<this.numIndices; index++) {
				this.add(0.0f);
			}
			
			// Parse the String[] to extract the values 
			parseUserInput(userInput);
		}

	}

	
	
	private void parseUserInput(String[] userInput) {
		/**
		 * Method to extract the String values from the String[] and convert them to floating point numbers to store in this
		 * 
		 * @param userInput A String array containing the necessary information to create an entry in the dataset (an instance of UserData)
		 */

		// For each index of the userInput...
		for(int i=0; i<userInput.length; i++) {
			
			// Ensure that the entry at that index is not empty
			if(userInput[i].isEmpty()) {
				this.set(i, 0f);
				continue;
			}
			
        	// Store the value in variable d
        	String d = userInput[i].strip();
        	
        	// Go to the corresponding index and convert the value
        	switch(i) {
        	
        		// Sex
        		case 1:
        			switch(d) {
						case "M": this.set(i, 0f); break;
						case "F": this.set(i, 1f); break;
        			} break;
        			
        		// ChestPainType
        		case 2:
        			switch(d) {
        				case "ATA": this.set(i, 0f); break;
        				case "NAP": this.set(i, 1f); break;
        				case "ASY": this.set(i, 2f); break;
        				case "TA":  this.set(i, 3f); break;
        			} break;
        		
        		// RestingBP - handle null value 0 by setting entry to average non-zero value in dataset, which is 133
        		case 3:
        			switch(d) {
        				case "0": this.set(i, 133f); break;
        				default: 
        					try {
        						float val = Float.parseFloat(userInput[i]);
        						this.set(i, val);
        					}
        					catch(NumberFormatException nfe) {
        						throw new IllegalArgumentException("Invalid number format at index " + i);
        					}
        			} break;
    			
        			
    			// Cholesterol - handle null value 0 by setting entry to average non-zero value in dataset, which is 245
        		case 4:
        			switch(d) {
        				case "0": this.set(i, 245f); break;
        				default: 
        					try {
        						float val = Float.parseFloat(userInput[i]);
        						this.set(i, val);
        					}
        					catch(NumberFormatException nfe) {
        						throw new IllegalArgumentException("Invalid number format at index " + i);
        					}
        			} break;
    			
        		// RestingECG
        		case 6:
        			switch(d) {
        				case "Normal": 	this.set(i, 0f); break;
        				case "ST": 		this.set(i, 1f); break;
        				case "LVH": 	this.set(i, 2f); break;
        			} break;
        			
        		// ExerciseAngina
        		case 8:
        			switch(d) {
						case "N": this.set(i, 0f); break;
						case "Y": this.set(i, 1f); break;						
					} break;
        		
				// ST_Slope	
        		case 10:
        			switch(d) {
        				case "Down": this.set(i, 0f); break;
        				case "Flat": this.set(i, 1f); break;
        				case "Up":   this.set(i, 2f); break;
        			} break;
        		
        		// Everything else should be parsed as a Float and added
        		default:
        			try {
        				float val = Float.parseFloat(userInput[i]);
        				this.set(i, val);
        			}
        			catch(NumberFormatException nfe) {
        			    throw new IllegalArgumentException("Invalid number format at index " + i);
        			}
        			
        	} // end of switch

			
		}	// end of for-loop that formats a UserData
			
	}	// parseUserInput
	

	
	public void normalize(int index, float min, float max) {
		/**
		 * Method to normalize the value of an index to ensure that all values fall on the interval [0, 1]
		 * 
		 * @param index the index of the UserData instance being normalized
		 * @param min the minimum value stored at this index in the dataset
		 * @param max the maximum value stored at this index in the dataset
		 */
		
		// Replace each entry at that index with the normalized value, calculated by (value - min) / (max - min)
		float value = this.get(index).floatValue();
		float normalizedValue = (value - min) / (max - min);
		this.set(index, normalizedValue);
		
	}	// normalize
	
	
	public void normalize(Dataset d) {
		/**
		 * Method to normalize a new entry in a dataset to ensure that all values fall on the interval [0, 1]
		 * 
		 * @param d the dataset being normalized to
		 */
		
		// Extract the min and max values of the dataset
		ArrayList<Float> maxValues = d.getFeatureMaxValues();
		ArrayList<Float> minValues = d.getFeatureMinValues();

		// Replace each entry at that index with the normalized value, calculated by (value - min) / (max - min)
		for(int index=0; index<this.numIndices; index++) {
			
			float max = maxValues.get(index);
			float min = minValues.get(index);
			
			float value = this.get(index).floatValue();
			float normalizedValue = (value - min) / (max - min);
			this.set(index, normalizedValue);
		}
		
		
	}	// normalize
	
	
	public UserData denormalize(Dataset d) {
		/**
		 * Method to denormalize an entry in a dataset back to the value its meant to represent
		 * 
		 * @param d the dataset being normalized to
		 */
		
		// Create a new UserData to store the denormalized values in
		UserData denormalizedValues = new UserData();
		
		// Extract the min and max values of the dataset
		ArrayList<Float> maxValues = d.getFeatureMaxValues();
		ArrayList<Float> minValues = d.getFeatureMinValues();
		
		// Replace each entry at that index with the normalized value, calculated by (value - min) / (max - min)
		for(int index=0; index<this.numIndices; index++) {
			
			float max = maxValues.get(index);
			float min = minValues.get(index);
			float normalizedValue = this.get(index).floatValue();
			
			float denormalizedValue = (normalizedValue * (max - min)) + min;
			denormalizedValues.set(index, denormalizedValue);
		}
				
		return denormalizedValues;
		
	}	// normalize
	
	
	public UserData getAdditionalInformation(Dataset d) {
		/**
		 * Method to get additional information to provide for the user
		 * 
		 * @param d The dataset the UserData belongs to
		 */
		
		Dataset filteredDataset = d.newCopy();
    	filteredDataset.filterAgeAndSex(this);
    	
    	UserData avgValues = filteredDataset.getAvgValues();
    	return avgValues;
	}
	
	
	
	public UserData newCopy() {
		/**
		 * Method to create a new UserData object that is a copy of this one
		 */
		
		UserData copyUserData = new UserData();
		
		for(int i=0; i<this.size(); i++) {
			Float toAdd = Float.parseFloat(String.valueOf(this.get(i)));
			copyUserData.add(toAdd);	
		}		

		return copyUserData;
	}
	
	
	public String[] returnUserData() {
		/**
		 * Method to return the UserData in the form of a String[]
		 */
		
		if(this.get(0) == null) return null;
		
		String[] s = new String[this.numIndices];
		
		for(int i=0; i<this.numIndices; i++) {
			s[i] = this.get(i).toString();
		}
		
		return s;
	}
	
	
	@Override
	public String toString() {

		if(this.get(0) == null) return null;
		
		String s = "[";
		for(int index = 0; index<this.size(); index++) {
			
			if(this.get(index) == null){
				s += "NaN" + ",  ";
			}
			else {
				s += this.get(index).toString() + ",  ";
			}
		}
		
		s = s.substring(0, s.length()-3) + "]";
		
		return s;
		
	}
	
	private static void SOP(Object O) {
		System.out.println(O);
	}

	public static int getDESIRED_NUM_INDICES() {
		return DESIRED_NUM_INDICES;
	}


	
}
