package main;

import java.util.ArrayList;

/**
 * @author Nicholas Farkash
 */

public class Validation{

	protected Dataset trainingData;		// Dataset storing the training dataset
	protected Dataset testingData;		// Dataset storing each testing dataset
	protected float inSampleError;		// E_in produced during validation
	

	
	public Validation(Dataset motherDataset) {
		/**
		 * Constructor for ValidationData
		 * 
		 * @param motherDataset The dataset this was created from
		 */
		
		// Initialize instance variables
		trainingData = new Dataset();
		testingData = new Dataset();
			
		// Split the data into an 80-20 split
		splitData(motherDataset);
	}
	
	
	private void splitData(Dataset motherDataset) {
		/**
		 * Method to split the dataset into 80% training and 20% validation
		 */
		
		Dataset copy = motherDataset.deepCopy();
		
		int numTotalTrainingPoints = (int) Math.floor(copy.size() * .8);
		
		// Pick numTotalTrainingPoints datapoints and move them to training Data
		for(int i=0; i < numTotalTrainingPoints; i++) {
			
			// Pick a random number between 0 and copy.size()
			int n = (int) Math.floor(Math.random() * (copy.size()-1));
			
			// Remove that data point from copy and add it to training
			UserData moveThis = copy.remove(n);
			this.trainingData.add(moveThis);
		}
				
		// The remaining points are the testing dataset
		this.testingData = copy;
		
	}	// splitData()
	

	
	private static void SOP(Object o) {
    	System.out.println(o + "\n");
    }
	
	private static void SOP(ArrayList<Dataset> o) {		
		for(Dataset d : o) {
			SOP(d);
		}
    }
	
}
