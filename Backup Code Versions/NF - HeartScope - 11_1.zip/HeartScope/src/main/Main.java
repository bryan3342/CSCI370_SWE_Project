package main;

import java.io.*;





import ru.ml.rf.RandomForest;
import ru.ml.rf.TestTrain;
import ru.ml.rf.DataSet;
import ru.ml.rf.Instance;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;




public class Main {
	

	
    public static void main(String[] args){
    	
    	
    	
        // Import the dataset
        String originalDataFilePath = "src/data/HeartScope_Dataset.csv";
    	Dataset dataset = new Dataset(originalDataFilePath, true);
    	SOP("Dataset Created");
    	//SOP(dataset);
    	//SOP(dataset.getShape());

    	
    	
    	// Make a copy of the dataset and normalize the copy, preserving the original dataset
    	Dataset normalizedDataset = dataset.newCopy();
    	normalizedDataset.normalizeDataset();
    	SOP("Dataset Normalized");
    	//SOP(normalizedDataset);
    	//SOP(normalizedDataset.getShape());

		
    	
    	// Create and Train Random Forest
    	
    	
    	
    	
    	// Get UserInput
    	SOP("Getting UserInput...");
    	String userInput = "55,F,ATA, 130, 215, 0, LVH, 132, Y, 0, Up, 0";
    	SOP("UserInput:\t " + userInput);

    	SOP("Converting UserInput to UserData...");
        UserData fakeUser = new UserData(userInput);
    	SOP("UserData:\t " + fakeUser);

    	SOP("Normalizing User into the Normalized Dataset...");
        fakeUser.normalize(normalizedDataset);
    	SOP("Normalized UserInput:\t " + fakeUser);


    	
        
        // Make a prediction
        

    	
    	
    	// Get the additional information for that user
    	SOP("Calculating Average Values within the user's range...");
    	UserData normalizedAverageValues = fakeUser.getAdditionalInformation(normalizedDataset);
    	SOP("Normalized Avg Values:\t " + normalizedAverageValues);   	
    	
    	SOP("Denormalizing the values...");
    	UserData avgValues = normalizedAverageValues.denormalize(normalizedDataset);
    	SOP("Avg Values:\t " + avgValues);

    	
    	
    	// Display the results to the user
    	
    	

    	    	
    }
    
    
    
    private static void SOP(Object o) {
    	System.out.println(o + "\n");
    }

    
    
    private static void SOP(String[] s) {
    	
    	if(s == null) return;
    	
    	String total = "";
    	for(String a : s) {
    		total += a + ",\t";
    	}
    	SOP(total.substring(0, total.length()-1));
    }
    
}















