package main;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class Dataset extends ArrayList<UserData> {

	// Instance Variables
	private String[] headers = null;	// The names of attributes/features of the dataset
	private int numFeatures = 12;	// The number of features in the dataset (length of headers)
	private String filePath = null;		// The path to the .csv file the dataset imported
	private ArrayList<Float> featureMaxValues;
	private ArrayList<Float> featureMinValues;
	
	
	public Dataset() {
		/**
		 * Constructor of Dataset
		 */
		
		this.featureMaxValues = new ArrayList<Float>() {{
			for(int i=0; i<numFeatures; i++) {
				add(0f);
			}
		}};
		
		this.featureMinValues = new ArrayList<Float>() {{
			for(int i=0; i<numFeatures; i++) {
				add(0f);
			}
		}};

	}
	
	
	
	public Dataset(String file, boolean containsHeader) {
		/**
		 * Constructor of Dataset
		 * 
		 * @param file Path to the file containing the .csv file to import
		 * @param containsHeader Boolean flag for whether the .csv file has a header row
		 * 
		 */
		this.featureMaxValues = new UserData();
		this.featureMinValues = new UserData();
		
		importCSV(file, containsHeader);
	}
	
	
	
	public void importCSV(String file, boolean containsHeader) {
		/**
		 * Method to import the data from a .csv file
		 * 
		 * @param file Path to the file containing the .csv file to import
		 * @param containsHeader Boolean flag for whether the .csv file has a header row
		 * 
		 */
		
		// Ensure that the file is a .csv file
		String fileExtension = file.substring(file.length() - 4);
		if(!fileExtension.equals(".csv")) throw new IllegalArgumentException("File must be a .csv file");
		
		// Update the filePath and flag the Dataset as being linked to a CSV file
		this.filePath = file;
		
		// Import the data
		importData(containsHeader);
		
	}	// importCSV
	
	
	
	public void importData(boolean containsHeader) {
		/**
		 * Method to import and format the data from the linked .csv file
		 * 
		 * @param containsHeader Boolean flag for whether the .csv file has a header row
		 *
		 */

			
		// Read through the CSV file
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
			
			// Manage the header line
        	if(containsHeader) {
	            this.headers = br.readLine().split(",");
	            this.numFeatures = headers.length;
        	}

            // Create a UserData item for each entry in the original dataset and add it to this
        	String line;
            int counter = 0; // Counter for number of data points
            
            while ((line = br.readLine()) != null) {
            	counter++;	// Increment the counter
            	
            	// Tokenize the dataset entry
                String[] rawUserDataValues = line.split(",");
                
                // Create a new UserData entry out of the original dataset entry and add it to the dataset
                UserData e = new UserData(rawUserDataValues);
                this.add(e);

            } // end of reading
            
            // Set the number of entries in the Database
            //this.setNumEntries(counter);
        }
        catch (IOException e) {
            e.printStackTrace();
        }

	}	//importData
		
	
	
	public void normalizeDataset() {
		/**
		 * Method to normalize a Dataset so that all values fall within the range of [0,1]
		 */

		// For each feature, calculate the maximum and minimum value
		for(int index=0; index<this.numFeatures; index++) {	
	
			// Find min and max values for the feature
			float min = Float.MAX_VALUE;
			float max = -Float.MAX_VALUE;
			for(int entry=0; entry<this.size(); entry++) {
				float temp = this.get(entry).get(index).floatValue();
				min = Math.min(min, temp);
				max = Math.max(max, temp);
			}
			this.featureMaxValues.set(index, max);
			this.featureMinValues.set(index, min);
			
		}	// for-loop
		
		// For each entry in the Dataset, normalize it
		for(UserData entry : this) {
			for(int index=0; index<this.numFeatures; index++) {
				
				float max = this.featureMaxValues.get(index);
				float min = this.featureMinValues.get(index);
				
				// If max == min, which may happen if the Dataset only has one entry, 
				if(max == min) {
					entry.set(index, max);
				}
				else {
					entry.normalize(index, min, max);
				}
			}
		}
				
	}	// normalizeDataset
	
	
	public boolean filterAgeAndSex(UserData curUser) {
		/**
		 * Method to return a new, modified Databse where all entires are of the same sex of a given user and within a 2 year age span
		 * Returns true if age filtering is applied, false otherwise
		 * 
		 * @param curUser The user whose age and sex are being filtered by
		 */
		
		// Create ArrayLists to store the entries to remove
		ArrayList<UserData> wrongSex = new ArrayList<UserData>();
		ArrayList<UserData> rightSexWrongAge = new ArrayList<UserData>();
		ArrayList<UserData> rightSexAndAge = new ArrayList<UserData>();

		
		// Get the current user's age and sex
		float curUserAge = curUser.get(0).floatValue();
		float curUserSex = curUser.get(1).floatValue();
				
		// Iterate through all entries in the Dataset 
		for(UserData dataEntry : this) {
						
			// Extract the entry's age and sex
			float age = dataEntry.get(0).floatValue();
			float sex = dataEntry.get(1).floatValue();
						
			// Compare the entry's data to curUser's data
			boolean validAge = Math.abs(curUserAge - age) <= 2.0; 
			boolean validSex = curUserSex == sex;
			
			// If the sex does not match, add the entry to wrongSex
			if(!validSex) {
				wrongSex.add(dataEntry);
			}
			// If the sex do match but the age does not, add the entry to rightSexWrongAge
			else if(!validAge) {
				rightSexWrongAge.add(dataEntry);
			}
			// If the both the sex and age match, add the entry to rightSexAndAge
			else {
				rightSexAndAge.add(dataEntry);
			}
	    }
		
		// Remove all entries with the wrong sex
		for(UserData entry : wrongSex){
			this.remove(entry);
		}
		
		// Remove all entries with the wrong age. However, if that results in removing everything, then remove nothing
		
		// If the dataset is the same size as what we want to remove, remove nothing and just return false to signal no age filter applied
		if(this.size() == rightSexWrongAge.size()) {
			return false;
		}
		
		// Otherwise, remove the entries with the wrong age
		else {
			for(UserData entry : rightSexWrongAge){
				this.remove(entry);
			}
			return true;
		}
		
		
		
			    
	}	// filterAgeAndSex
	
	
	public UserData getAvgValues() {
		/**
		 * Method to get the average values for each feature in a Dataset
		 */
		
		// If there are no entries in the database, return a UserData with null values
		if(this.size() == 0) {
			UserData nulled = new UserData();
			for(int i=0; i<UserData.getDESIRED_NUM_INDICES(); i++) {
				nulled.set(i, null);
			}
			return nulled;
		}
		
		// Create a UserData to store the calculated average values
		UserData avgValues = new UserData();
		
		// Avg over quantitative features, take mode of catagorical features
		int[] indicesOfQuantitativeFeatures = {0, 3, 4, 5, 7, 9};
		
		
		// For each quantitative feature column, calculate the average value and store it at its corresponding index
		for(int index : indicesOfQuantitativeFeatures) {
			
			float sum = 0.0f;
			for(UserData entry : this) {
				sum += entry.get(index).floatValue();
			}
			
			avgValues.set(index, sum/this.size());
		}
		
		
		
		
		// For each categorical feature column, calculate the mode value and store it at its corresponding index
		int[] indicesOfCategoricalFeatures = {1, 2, 6, 8, 10, 11};

		ArrayList<ArrayList<Float>> quantFeatures = new ArrayList<ArrayList<Float>>();

		// Store all values for each column 
		for(int index : indicesOfCategoricalFeatures) {

			ArrayList<Float> featureColumn = new ArrayList<Float>();
			for(UserData entry : this) {
				featureColumn.add(entry.get(index));
			}
			quantFeatures.add(featureColumn);
		}
		
		// Calculate the Mode for each column
		ArrayList<Float> modes = new ArrayList<Float>();
		for(ArrayList<Float> featureColumn : quantFeatures) {
			
			HashMap<Float, Integer> frequency = new HashMap<>();
			
			// Count occurrences of each element
	        for (Float num : featureColumn) {
	        	frequency.put(num, frequency.getOrDefault(num, 0) + 1);
	        }
	        
	        // Find the element with the highest frequency
	        Float mode = null;
	        int maxCount = 0;
	        for (Map.Entry<Float, Integer> entry : frequency.entrySet()) {
	            if (entry.getValue() > maxCount) {
	                mode = entry.getKey();
	                maxCount = entry.getValue();
	            }
	        }
	        
	        modes.add(mode);
		}
		
		for(int i=0; i<indicesOfCategoricalFeatures.length; i++) {
			avgValues.set(indicesOfCategoricalFeatures[i], modes.get(i));
		}	
		
		// Return the ArrayList
		return avgValues;	
	
	}	// getAvgValues
	
	
	public Dataset newCopy() {
		/**
		 * Method to create a new Dataset object that is a copy of this one
		 */
		
		Dataset copyDataset = new Dataset();
		
		for(int i=0; i<this.size(); i++) {
			UserData toAdd = this.get(i);	
			copyDataset.add(toAdd);	
		}
		
		return copyDataset;
		
	}
	
	
	@Override
 	public String toString() {
		String s = "";
		
		for(UserData entry : this) {
			s += entry;
		}
		
		return s;
			
	}
	
	@Override
	public boolean add(UserData u) {
		if (super.add(u)) {
			return true;
		}
		return false;
	}
	
	public String getShape() {
		/**
		 * Method to get the dimensions of the Dataset
		 */
		
		return this.size() + ", " + this.numFeatures + "\n";
	}

		
	
	public int getNumFeatures() {
		return this.numFeatures ;
	}
	
	public ArrayList<Float> getFeatureMaxValues() {
		return this.featureMaxValues;
	}
	
	public ArrayList<Float> getFeatureMinValues() {
		return this.featureMinValues;
	}
		
	private static void SOP(Object O) {
		System.out.println(O);
	}

	
}


