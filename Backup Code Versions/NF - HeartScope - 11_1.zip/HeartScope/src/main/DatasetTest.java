package main;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import java.util.Arrays;

import org.junit.jupiter.api.Test;

class DatasetTest {

	Dataset originalDataset;
	Dataset expectedDataset;
	Dataset actualDataset;
	
	@Test
	void FilterDatasetTestNormal() {
		originalDataset = new Dataset();

		String[] originalTestEntries = new String[]{
				"44,M,ATA,140,289,0,Normal,172,N,0,Up,0",
				"45,M,NAP,160,180,0,Normal,156,N,1,Flat,1",
				"46,M,ATA,130,283,0,ST,98,N,0,Up,0",
				"47,M,ASY,138,214,0,Normal,108,Y,1.5,Flat,1",
				"48,M,NAP,150,195,0,Normal,122,N,0,Up,0",
				"49,M,NAP,120,339,0,Normal,170,N,0,Up,0",
				"50,M,ASY,140,207,0,Normal,130,Y,1.5,Flat,1",
				"44,F,ATA,140,289,0,Normal,172,N,0,Up,0",
				"45,F,NAP,160,180,0,Normal,156,N,1,Flat,1",
				"46,F,ATA,130,283,0,ST,98,N,0,Up,0",
				"47,F,ASY,138,214,0,Normal,108,Y,1.5,Flat,1",
				"48,F,NAP,150,195,0,Normal,122,N,0,Up,0",
				"49,F,NAP,120,339,0,Normal,170,N,0,Up,0",
				"50,F,ASY,140,207,0,Normal,130,Y,1.5,Flat,1",
		};
		 
		for(String e : originalTestEntries) {
			originalDataset.add(new UserData(e));
		}
		 
		// Create the expectation
		UserData testUser = new UserData("47,M,ASY,138,214,0,Normal,108,Y,1.5,Flat,1");
		expectedDataset = new Dataset();
		 
		String[] expectedTestEntries = new String[]{
				"45,M,NAP,160,180,0,Normal,156,N,1,Flat,1",
				"46,M,ATA,130,283,0,ST,98,N,0,Up,0",
				"47,M,ASY,138,214,0,Normal,108,Y,1.5,Flat,1",
				"48,M,NAP,150,195,0,Normal,122,N,0,Up,0",
				"49,M,NAP,120,339,0,Normal,170,N,0,Up,0",
		};
		 
		for(String e : expectedTestEntries) {
			expectedDataset.add(new UserData(e));
		}
		 
		// Create the actual
		originalDataset.filterAgeAndSex(testUser);
		actualDataset = originalDataset.newCopy();
		 
	   	// Assert that expected equals actual 	
		assertEquals(expectedDataset, actualDataset);
		
	}
	
	
	@Test
	void FilterDatasetTestNoMatches() {
		originalDataset = new Dataset();

		String[] originalTestEntries = new String[]{
				"44,M,ATA,140,289,0,Normal,172,N,0,Up,0",
				"45,M,NAP,160,180,0,Normal,156,N,1,Flat,1",
				"46,M,ATA,130,283,0,ST,98,N,0,Up,0",
				"47,M,ASY,138,214,0,Normal,108,Y,1.5,Flat,1",
				"48,M,NAP,150,195,0,Normal,122,N,0,Up,0",
				"49,M,NAP,120,339,0,Normal,170,N,0,Up,0",
				"50,M,ASY,140,207,0,Normal,130,Y,1.5,Flat,1",
				"44,F,ATA,140,289,0,Normal,172,N,0,Up,0",
				"45,F,NAP,160,180,0,Normal,156,N,1,Flat,1",
				"46,F,ATA,130,283,0,ST,98,N,0,Up,0",
				"47,F,ASY,138,214,0,Normal,108,Y,1.5,Flat,1",
				"48,F,NAP,150,195,0,Normal,122,N,0,Up,0",
				"49,F,NAP,120,339,0,Normal,170,N,0,Up,0",
			 	"50,F,ASY,140,207,0,Normal,130,Y,1.5,Flat,1",
		};
		 
		for(String e : originalTestEntries) {
			 originalDataset.add(new UserData(e));
		}
		 
		// Create the expectation
		UserData testUser = new UserData("80,M,ASY,138,214,0,Normal,108,Y,1.5,Flat,1");
		expectedDataset = new Dataset();
		
		String[] expectedTestEntries = new String[]{
				"44,M,ATA,140,289,0,Normal,172,N,0,Up,0",
				"45,M,NAP,160,180,0,Normal,156,N,1,Flat,1",
				"46,M,ATA,130,283,0,ST,98,N,0,Up,0",
				"47,M,ASY,138,214,0,Normal,108,Y,1.5,Flat,1",
				"48,M,NAP,150,195,0,Normal,122,N,0,Up,0",
				"49,M,NAP,120,339,0,Normal,170,N,0,Up,0",
				"50,M,ASY,140,207,0,Normal,130,Y,1.5,Flat,1"
		};
		 
		for(String e : expectedTestEntries) {
			expectedDataset.add(new UserData(e));
		}
		 
		// Create the actual
		originalDataset.filterAgeAndSex(testUser);
		actualDataset = originalDataset.newCopy();
		 
   		// Assert that expected equals actual 	
		assertEquals(expectedDataset, actualDataset);
	}
	
	
	@Test
	void getAverageValuesTestNormal() {
		originalDataset = new Dataset();

		String[] originalTestEntries = new String[]{
				 "40,M,ATA,140,289,0,Normal,172,N,0,Up,0",
				 "40,M,NAP,160,180,0,Normal,156,N,1,Flat,1",
				 "40,M,NAP,130,211,0,Normal,142,N,0,Up,0",
				 "40,M,ATA,120,204,0,Normal,145,N,0,Up,0",
				 "41,M,ATA,130,283,0,ST,98,N,0,Up,0",
				 "41,M,ASY,138,214,0,Normal,108,Y,1.5,Flat,1",
				 "41,M,ATA,136,164,0,ST,99,Y,2,Flat,1",
				 "41,M,ASY,140,234,0,Normal,140,Y,1,Flat,1",
				 "42,M,NAP,150,195,0,Normal,122,N,0,Up,0",
				 "42,M,NAP,120,339,0,Normal,170,N,0,Up,0",
				 "42,M,NAP,115,211,0,ST,137,N,0,Up,0",
				 "43,M,ATA,130,237,0,Normal,170,N,0,Up,0",
				 "43,M,ATA,110,208,0,Normal,142,N,0,Up,0",
				 "43,M,ATA,120,273,0,Normal,150,N,1.5,Flat,0",
				 "44,M,ASY,140,207,0,Normal,130,Y,1.5,Flat,1",
				 "44,M,ATA,120,284,0,Normal,120,N,0,Up,0",
				 "44,M,ASY,110,196,0,Normal,166,N,0,Flat,1",
				 "44,M,ATA,120,201,0,Normal,165,N,0,Up,0",
		 };
		 
		for(String e : originalTestEntries) {
			originalDataset.add(new UserData(e));
		}
		 		 
		// Create the expectation	 
		UserData expected = new UserData("41.9444444,M,ATA, 129.3888888,229.4444444,0,Normal,140.6666666,N,0.4722222,Up,0");

		// Create the actual
		UserData actual = originalDataset.getAvgValues();
		 
	   	// Assert that expected equals actual 	
		assertEquals(expected, actual);
	}
	
	
	
	@Test
	void getAverageValuesTestEmptyFilter() {
		originalDataset = new Dataset();

		String[] originalTestEntries = new String[]{};
		 
		for(String e : originalTestEntries) {
			originalDataset.add(new UserData(e));
		}
		 
		// Create the expectation	 
		Float[] nulls = {null,null,null,null,null,null,null,null,null,null,null,null};
		ArrayList<Float> expected = new ArrayList<Float>(Arrays.asList(nulls));
		
		// Create the actual
		UserData actual = originalDataset.getAvgValues();
		 
		// Assert that expected equals actual 	
		assertEquals(expected, actual);
	}
	
	
	
	@Test
	void getNormalizedDataZeroEntriesTest() {
		originalDataset = new Dataset();

		String[] originalTestEntries = new String[]{
		};
		 
		for(String e : originalTestEntries) {
			originalDataset.add(new UserData(e));
		}
		 
		// Create the expectation
		expectedDataset = new Dataset();

		// Create the actual
		originalDataset.normalizeDataset();
		actualDataset = originalDataset.newCopy();
		
		// Assert that expected equals actual 	
		assertEquals(expectedDataset, actualDataset);
	}
	
	
	
	@Test
	void getNormalizedDataOneEntryTest() {
		originalDataset = new Dataset();

		String[] originalTestEntries = new String[]{
				"44,M,ATA,140,289,0,Normal,172,N,0,Up,0"
		};
		 
		for(String e : originalTestEntries) {
			originalDataset.add(new UserData(e));
		}
		 
		// Create the expectation
		expectedDataset = new Dataset();
		expectedDataset.add(new UserData("44,M,ATA,140,289,0,Normal,172,N,0,Up,0"));

		// Create the actual
		originalDataset.normalizeDataset();
		actualDataset = originalDataset.newCopy();
		
		// Assert that expected equals actual 	
		assertEquals(expectedDataset, actualDataset);
	}
	
	@Test
	void getNormalizedDataMultipleEntriesTest() {
		originalDataset = new Dataset();

		String[] originalTestEntries = new String[]{
				"40,M,ATA,140,289,0,Normal,172,N,0,Up,0",
				"49,F,NAP,160,180,0,Normal,156,N,1,Flat,1",
				"37,M,ATA,130,283,0,ST,98,N,0,Up,0",
		};
		 
		for(String e : originalTestEntries) {
			originalDataset.add(new UserData(e));
		}
		 
		// Create the expectation
		expectedDataset = new Dataset();
		
		Float[] u1Normalized = {0.25f, 0f, 0f, 0.3333333333f, 1f, 0f, 0f, 1f, 0f, 0f, 1f, 0f};
		Float[] u2Normalized = {1f, 1f, 1f, 1f, 0f, 0f, 0f, 0.7837837838f, 0f, 1f, 0f, 1f};
		Float[] u3Normalized = {0f, 0f, 0f, 0f, .9449541284f, 0f, 1f, 0f, 0f, 0f, 1f, 0f};
		
		UserData u1 = new UserData() {{
			for(int i=0; i<this.getDESIRED_NUM_INDICES(); i++) {
				this.set(i, u1Normalized[i]);
			}
		}};
		
		UserData u2 = new UserData() {{
			for(int i=0; i<this.getDESIRED_NUM_INDICES(); i++) {
				this.set(i, u2Normalized[i]);
			}
		}};
		
		UserData u3 = new UserData() {{
			for(int i=0; i<this.getDESIRED_NUM_INDICES(); i++) {
				this.set(i, u3Normalized[i]);
			}
		}};
		
		expectedDataset.add((UserData) u1);
		expectedDataset.add((UserData) u2);
		expectedDataset.add((UserData) u3);

		// Create the actual
		originalDataset.normalizeDataset();
		actualDataset = originalDataset.newCopy();
		
		// Assert that expected equals actual 	
		assertEquals(expectedDataset, actualDataset);
	}
	
	
	
	

}
