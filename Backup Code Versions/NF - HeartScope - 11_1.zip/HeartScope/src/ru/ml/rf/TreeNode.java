package ru.ml.rf;

public abstract class TreeNode {

    protected int depth;

    public TreeNode() {
        depth = 0;
    }
}
