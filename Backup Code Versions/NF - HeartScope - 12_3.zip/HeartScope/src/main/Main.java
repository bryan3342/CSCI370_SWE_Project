package main;

import java.util.ArrayList;



/**
 * @author Nicholas Farkash
 */

public class Main {
	

	
    public static void main(String[] args){
    	
    	
    	
        // Import the dataset
        String originalDataFilePath = "src/data/HeartScope_Dataset.csv";
    	Dataset dataset = new Dataset(originalDataFilePath, true);
    	SOP("Dataset Created");
    	//SOP(dataset);
    	//SOP(dataset.getShape());

    	
    	// Split the Dataset into a ValidationData object, which stores 10 folds of training and testing data
    	Validation validation = new Validation(dataset);
    	ArrayList<Dataset> trainingFolds = validation.trainingDataFolds;
    	ArrayList<Dataset> testingFolds = validation.testingDataFolds;

    	
    	// TODO Create and Train Random Forest
    	
    	
    	
    	
    	
    	
    	// Make a prediction
    	
    	
    	// Get UserInput
    	SOP("Getting UserInput...");
    	String[] userInput =  {"55", "F", "ATA", "130", "", "0", "", "132", "", "", "", ""};
    	SOP(userInput);

    	SOP("Converting UserInput to UserData...");
        UserData fakeUser = new UserData(userInput);
    	SOP(fakeUser);

    	
   
        // TODO Predict
        

    	
    	
    	// Get the additional information for that user
    	SOP("Calculating Average Values within the user's range...");
    	UserData averageValues = fakeUser.getAdditionalInformation(dataset);
    	SOP("Normalized Avg Values:\t " + averageValues);   	
    	
    	
    	
    	
    	// TODO Display the results to the user
    	SOP("Finished");
    	System.exit(0);
    }
    
    
    
    private static void SOP(Object o) {
    	System.out.println(o + "\n");
    }
    
    private static void SOP(String[] O) {
		for(String s : O) {
			System.out.print(s + ", ");
		}
		SOP("");
	}
}

